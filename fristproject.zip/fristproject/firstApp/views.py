from email import message
from django.shortcuts import render
from django.http import HttpResponse

def wish(request):
    message = """
    <title>site title </title>
    <h1>WELCOME TO MY SITE </h1>
    <br>
    <h2>first look</h2>
    <H4><img src="https://media.istockphoto.com/photos/remote-working-from-home-freelancer-workplace-in-kitchen-with-laptop-picture-id1213497796?k=20&m=1213497796&s=612x612&w=0&h=rnC6fdv3g1kAwu9TFJFRjfeAyxWutJCgrsHRShOuqGk=" width=75% alt="image"></H4>
    <p>let's start your work </p>
    <a href="https://www.instagram.com/?hl=en">this insta link </a>
    
    """
    
    return HttpResponse(message)

# Create your views here.
